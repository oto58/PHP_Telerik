-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.27
-- Версия на PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `telerik`
--
CREATE DATABASE `telerik` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `telerik`;

-- --------------------------------------------------------

--
-- Структура на таблица `msg`
--

CREATE TABLE IF NOT EXISTS `msg` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `msg_user` varchar(50) NOT NULL,
  `msg_title` varchar(50) NOT NULL,
  `msg_txt` text NOT NULL,
  `msg_group` varchar(50) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Ссхема на данните от таблица `msg`
--

INSERT INTO `msg` (`msg_id`, `msg_date`, `msg_user`, `msg_title`, `msg_txt`, `msg_group`) VALUES
(1, '2013-10-07 08:47:28', 'admin', 'правила', 'Потребителят с име admin и парола qwerty има права да изтрива съобщения.', 'админ'),
(2, '2013-10-07 08:49:33', 'user1', 'отговор', 'Останалите потребители не могат да изтриват.', 'разни'),
(3, '2013-10-07 08:51:04', 'user1', 'пост', 'потребител user1 с парола qwerty', 'админ'),
(4, '2013-10-07 08:52:27', 'user2', 'пост', 'потребител user2 с парола qwerty', 'админ'),
(5, '2013-10-07 08:56:08', 'user2', 'пост', 'Нещо написано', 'разни');

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_statute` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Ссхема на данните от таблица `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `password`, `user_statute`) VALUES
(1, 'admin', 'qwerty', 1),
(2, 'user1', 'qwerty', 0),
(3, 'user2', 'qwerty', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
